package e.caioluis.nybooksteste.data.model

data class Book (
    val title: String,
    val author: String
)